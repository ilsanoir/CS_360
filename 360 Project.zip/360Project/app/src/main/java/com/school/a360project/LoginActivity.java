package com.school.a360project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.school.a360project.R;


public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText username = findViewById(R.id.usernameTextInput1);
        EditText password = findViewById(R.id.passwordTextInput1);
        DatabaseHelper DB = new DatabaseHelper(this);

        Button login = findViewById(R.id.submitButton1);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals("")){
                    Toast.makeText(LoginActivity.this, "Please enter username and password", Toast.LENGTH_LONG).show();
                }
                else{
                    Boolean checkuserpass = DB.checkUsernamePassword(user, pass);
                        if (checkuserpass == true){
                            Toast.makeText(LoginActivity.this, "Signing In", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), DatabaseActivity.class);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(LoginActivity.this, "Username or password is not correct", Toast.LENGTH_LONG).show();
                        }
                    }
            }
        });

    }
}