package com.school.a360project;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class DatabaseActivity extends AppCompatActivity {

    LogDatabase weights = new LogDatabase(this);
    Button addLog = findViewById(R.id.addWeightButton);
    Button viewData = findViewById(R.id.viewDataButton);
    Button updateData = findViewById(R.id.updateDataButton);
    Button deleteData = findViewById(R.id.deleteDataButton);
    EditText weightEt = findViewById(R.id.weightEntry);
    EditText dateEt = findViewById(R.id.dateEntry);
    EditText idEt = findViewById(R.id.idEntry);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_log);

    }

    public void AddData(){
        addLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = weightEt.getText().toString();
                String date = dateEt.getText().toString();

                boolean insertData = weights.addData(weight, date);
                if(insertData == true){
                    Toast.makeText(DatabaseActivity.this, "Successfully added log",
                            Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(DatabaseActivity.this, "Log not added, try again",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void ViewData(){
        viewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor data = weights.showData();

                if(data.getCount() == 0){
                    Toast.makeText(DatabaseActivity.this, "No weights have been recorded",
                            Toast.LENGTH_LONG).show();
                }
                StringBuffer buffer = new StringBuffer();
                while(data.moveToNext()){
                    buffer.append("ID: " + data.getString(0));
                    buffer.append("Date: " + data.getString(1));
                    buffer.append("Weight: " + data.getString(2) + "\n");

                    display("All weights recorded:", buffer.toString());
                }
            }
        });
    }

    public void display(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void updateData(){
        updateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = idEt.getText().toString().length();
                if(temp > 0){
                    boolean update = weights.updateData(idEt.getText().toString(), dateEt.getText().toString(),
                            weightEt.getText().toString());

                    if(update == true){
                        Toast.makeText(DatabaseActivity.this, "Log updated", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(DatabaseActivity.this, "Log update failed", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    Toast.makeText(DatabaseActivity.this, "Enter ID to update", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void deleteData(){
        deleteData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int temp = idEt.getText().toString().length();
                if(temp > 0){
                    int deleteRow = weights.deleteData(idEt.getText().toString());
                    if(deleteRow > 0){
                        Toast.makeText(DatabaseActivity.this, "Log Deleted", Toast.LENGTH_LONG).show();
                    }

                    else{
                        Toast.makeText(DatabaseActivity.this, "Log deletion failed", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    Toast.makeText(DatabaseActivity.this, "Enter ID to update", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
