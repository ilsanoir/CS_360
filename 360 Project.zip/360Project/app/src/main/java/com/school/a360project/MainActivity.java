package com.school.a360project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    EditText username = findViewById(R.id.usernameTextInput);
    EditText password = findViewById(R.id.passwordTextInput);

    Button login = findViewById(R.id.submitButton);
    Button register = findViewById(R.id.newLoginButton);

    DatabaseHelper DB = new DatabaseHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals(""))
                    Toast.makeText(MainActivity.this, "Please enter the username and password", Toast.LENGTH_LONG);
                else{
                    Boolean checkuser = DB.checkUsername(user);
                    if(checkuser == false){
                        Boolean insert = DB.insertData(user, pass);
                        if(insert == true){
                            Toast.makeText(MainActivity.this, "Registered Successfully", Toast.LENGTH_SHORT);
                            Intent intent = new Intent(getApplicationContext(), DatabaseActivity.class);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(MainActivity.this, "Registration Failed", Toast.LENGTH_SHORT);
                        }
                    }
                    else{
                        Toast.makeText(MainActivity.this,"User already exists, please sign in", Toast.LENGTH_LONG);
                    }
                }

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);

            }
        });
    }
}