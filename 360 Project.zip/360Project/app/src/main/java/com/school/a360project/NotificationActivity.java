package com.school.a360project;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class NotificationActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prompt_screen);
        RadioButton toggle = findViewById(R.id.notificationButton);

        toggle.setActivated(false);
        if(toggle.isActivated()){

        }
        else{

        }
    }
}
